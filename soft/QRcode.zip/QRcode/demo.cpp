#include <stdio.h>
#include "./code/qrcode/QRCodeReader.h"
#include <highgui.h>
#include <cv.h>
#include<iostream>
using namespace cv;
using namespace std;
using namespace zxing;
//convert single char channel
void MatToCharImg(cv::Mat mat, char *pCharImg)
{
	int i = 0;
	int j = 0;
	int index = 0;
	for (i=0; i<mat.rows; i++)
	{
		const char *p = mat.ptr<char>(i);
		for (j=0; j<mat.cols; j++,p++)
		{
			pCharImg[index++] = *p;
		}
	}
}
//判断是否存在二维码
//return 1 存在 0 不存在
bool JudgeQrImg(char *pFilePath)
{
 	qrcode::GetQRcode qr;
	Ref<Result> result;
	ArrayRef< Ref<ResultPoint> > points;
	Mat frame = imread(pFilePath,1);
	CvCapture *capture = NULL;
	if (frame.data == NULL)
	{
		//video	
		capture = cvCreateFileCapture(pFilePath);
		if ( !capture )
			return 0;
		frame = cvQueryFrame(capture);
		if (frame.data == NULL)
			return 0;
	}
	Mat gray(frame.rows,frame.cols,CV_8UC(1), cv::Scalar::all(0));
	cvtColor(frame, gray, CV_BGR2GRAY);
	Size dz;
	if( MIN(gray.rows,gray.cols) < 250)
	{
		cv::resize(gray,gray,dz,3.0,3.0,1);
		cv::resize(frame,frame,dz,3.0,3.0,1);
	}
	int i = gray.rows * gray.cols;
	i = ((i+3)>>2)<<2;
	char *pCharImg = (char *)calloc(i,sizeof(char));
	//convert
	MatToCharImg(gray,pCharImg);
	//detect
	qr.QRdetectPoint(pCharImg,gray.cols,gray.rows);
	points = qr.GetPoints();
        //release capture  
	if (capture)
		cvReleaseCapture(&capture);
	if(points != NULL)
	{
	    return 1;
	}
        
	free(pCharImg);
	return 0;
}

int main(int argc, char *argv[])
{
	int nDet = JudgeQrImg(argv[1]);
    cout << nDet << endl;
	return 0;
}
