#ifndef __OpenBITMAPSOURCE_H__
#define __OpenBITMAPSOURCE_H__

#include "LuminanceSource.h"
using namespace zxing;

class OpenBitmapSource : public LuminanceSource
{
private:
	 char *pCharImg;
	 int width;
	 int height;

public:
	OpenBitmapSource( char *pCharImg,int width, int height);

	~OpenBitmapSource();

	int getWidth() const;   
	int getHeight() const;

	ArrayRef<char> getRow(int y, ArrayRef<char> row) const; //See Zxing Array.h for ArrayRef def

	ArrayRef<char> getMatrix() const;
};

#endif