#include "openbitmapsource.h"


OpenBitmapSource::OpenBitmapSource( char *pCharImg,int width, int height)
	:LuminanceSource(width,height)
{
	this->pCharImg = pCharImg;
	this->width = width;
	this->height = height;
}

OpenBitmapSource::~OpenBitmapSource()
{
}

int OpenBitmapSource::getWidth() const
{
	return this->width;
}

int OpenBitmapSource::getHeight() const
{
	return this->height;
}
ArrayRef<char> OpenBitmapSource::getRow(int y, ArrayRef<char> row) const
{
	int width_ = getWidth();
	int index = y * width_;
	if (!row)
		row = ArrayRef<char>(width_);
	char *p = &this->pCharImg[index];
	for(int x = 0; x<width_; ++x, ++p)
		row[x] = *p;
	return row;
}

ArrayRef<char> OpenBitmapSource::getMatrix() const
{
	int width_ = getWidth();
	int height_ =  getHeight();
	ArrayRef<char> matrix = ArrayRef<char>(width_ * height_);
	int index = 0;
	for (int y = 0; y < height_; ++y)
	{
	    char *p = &this->pCharImg[index];
		int yoffset = y * width_;
		for(int x = 0; x < width_; ++x, ++p)
		{
			matrix[yoffset + x] = *p;
		}
		index = index + width_;
	}
	return matrix;
}